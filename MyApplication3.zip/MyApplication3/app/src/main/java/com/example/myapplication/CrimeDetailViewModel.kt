import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapplication.Crime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CrimeDetailViewModel(initialCrime: Crime) : ViewModel() {
    private val _crime: MutableStateFlow<Crime?> = MutableStateFlow(initialCrime)
    val crime: StateFlow<Crime?> = _crime

    fun updateCrime(onUpdate: (Crime) -> Crime) {
        _crime.value = _crime.value?.let { onUpdate(it) }
    }
}

class CrimeDetailViewModelFactory(private val initialCrime: Crime) : ViewModelProvider.Factory {
    fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return CrimeDetailViewModel(initialCrime) as T
    }
}